#include<time.h>
#include <windows.h>
#include "mazeDynamic_stack.cpp"
#define M 10  						//迷宫的长
#define N 10  						//迷宫的宽
#define P 3   						//随机生成迷宫的路和墙的期望比值
int Maze[M][N],vis[M][N];
int count;							//第count条路径
int minlength=M*N;					//目前最小的路径长度
void Random()						//随机生成迷宫的函数
{
	srand(time(NULL));
	for(int i=1;i<=M-2;i++)//按照所给比例生成墙
		for(int j=1;j<=N-2;j++)
			if(!(rand()%P)) Maze[i][j]=1;
	for(int i=1;i<=M-2;i++)//如果一条路四周都是墙，那么全部打通
		for(int j=1;j<=N-2;j++)
			if(Maze[i][j]==0&&Maze[i+1][j]==1&&Maze[i-1][j]==1&&Maze[i][j+1]==1&&Maze[i][j-1]==1) Maze[i][j]=Maze[i+1][j]=Maze[i-1][j]=Maze[i][j+1]=Maze[i][j-1]==0;
	for(int i=0;i<=M-1;i++)//地图四周加墙防止越界
		Maze[i][0]=Maze[i][N-1]=1;
	for(int j=0;j<=N-1;j++)
		Maze[0][j]=Maze[M-1][j]=1;
	Maze[1][0]=Maze[1][1]=Maze[M-2][N-1]=Maze[M-2][N-2]=0;//起点右终点左打通
}
Status Judge(PosType e)				//判断是否可走
{
	if(e.x>=0&e.x<M&&e.y>=0&&e.y<N&&Maze[e.x][e.y]==0) return OK;
	return OVERFLOW;
}
PosType NextPos(PosType &e,int dir) //下一步
{
	PosType E;
	switch(dir)
	{
		case 1:E.x=e.x;E.y=e.y+1;;break;//向下
		case 2:E.x=e.x+1;E.y=e.y;;break;//向右	
    	case 3:E.x=e.x;E.y=e.y-1;;break;//向上
		default:E.x=e.x-1;E.y=e.y;;	   //向左   
	}
	return E;
}
void PrintMaze()					//打印迷宫
{
	for(int i=0;i<M;i++)
	{
		for(int j=0;j<N;j++)
		{
			if(Maze[i][j]==0&&vis[i][j]>0)
			{
				switch(vis[i][j])
				{
					case 1:printf("→");break;
					case 2:printf("↓");break;
					case 3:printf("←");break;
					default:printf("↑");
				}
			}
			else if(Maze[i][j]==1) printf("■");						//迷宫的墙
			else if(Maze[i][j]==0&&vis[i][j]==-1) printf("×");      //不通的路
			else printf("□");										//迷宫未走的路
		}
		puts("");
	}
	puts("");
}
Status DynamicMazePath(int maze,PosType start,PosType end,SqStack &s)
{
	PosType curpos;
	InitStack(s);
	SElemType e;
	int curstep;
	curpos=start;	// 设定"当前位置"为"入口位置"
	curstep=1;		// 探索第一步
	do
	{
		if(vis[1][1]==-1) 
		{
			vis[1][0]=-1;
			Sleep(500);
			system("cls");
			PrintMaze();
			return FALSE;
		}
		PrintMaze();
		if(!vis[curpos.x][curpos.y]&&Judge(curpos))
		{	//当前位置可通过，即是未曾走到过的通道块
			vis[curpos.x][curpos.y]=1;
			e.di=1;
            e.ord=curstep;
            e.seat=curpos;
			Push(s,e);	// 加入路径
			if(curpos.x==end.x&&curpos.y==end.y) 
			{
				vis[M-2][N-1]=1;
				Sleep(100);
				system("cls");
				PrintMaze();
				return TRUE;
			}
			curpos=NextPos(curpos,1);	// 下一位置是当前位置的右侧
			curstep++;	 //探索下一步
		}
		else
		{	//当前位置不能通过
			if(!StackEmpty(s))
			{
				Pop(s,e);
				while(e.di==4&&!StackEmpty(s))
				//四个方向均探索后说明该位置无法通过，为死角 
				{
					vis[e.seat.x][e.seat.y]=-1;
					Pop(s,e);
				}
				if(e.di<4)
				{
					e.di++;
					vis[e.seat.x][e.seat.y]++;
					Push(s,e);						//留下不能通过的标记，并退回一步
					curpos=NextPos(e.seat,e.di);	// 当前位置设为新方向的相邻块
				}
			}
		}
		Sleep(100);  	//延时 
		system("cls");  //清屏 
	}while(!StackEmpty(s));
	return FALSE;
}
void dfs(PosType start,PosType end,SqStack &s)
{
	if(start.x==end.x&&start.y==end.y)
	{
		printf("第%d条路径已找到！\n",++count);
		PrintMaze();
		return;
	}
	for(int i=1;i<=4;i++)
	{
		SElemType nextpos;
		nextpos.seat=NextPos(start,i);
		if(vis[nextpos.seat.x][nextpos.seat.y]||!Judge(nextpos.seat)) continue;
		vis[start.x][start.y]=i;
		vis[nextpos.seat.x][nextpos.seat.y]=1;
		Push(s,nextpos);
		dfs(nextpos.seat,end,s);
		vis[nextpos.seat.x][nextpos.seat.y]=0;
		Pop(s,nextpos);
	}
}
void dfs2(PosType start,PosType end,SqStack &s,int len)
{
	if(start.x==end.x&&start.y==end.y)
	{
		if(len==minlength) PrintMaze(),count++;
		else if(len<minlength)
		{
			minlength=len;
			system("cls");
			count=1;
			PrintMaze();
		}
		return;
	}
	for(int i=1;i<=4;i++)
	{
		SElemType nextpos;
		nextpos.seat=NextPos(start,i);
		if(vis[nextpos.seat.x][nextpos.seat.y]||!Judge(nextpos.seat)) continue;
		vis[start.x][start.y]=i;
		vis[nextpos.seat.x][nextpos.seat.y]=1;
		Push(s,nextpos);
		dfs2(nextpos.seat,end,s,len+1);
		vis[nextpos.seat.x][nextpos.seat.y]=0;
		Pop(s,nextpos);
	}
}
int main()
{
	int opt,opt2;
	while(1)
	{
		puts("请选择迷宫的生成方式：\n1.自动生成\n2.文件导入");
		scanf("%d",&opt);
		if(opt!=1&&opt!=2)
		{
			puts("输入非法！请再次输入！");
			continue;
		}
		break;
	}
	while(1)
	{
		puts("请选择生成路径的方式：\n1.动态显示一条\n2.多条路径\n3.最短路径");
		scanf("%d",&opt2);
		if(opt2!=1&&opt2!=2&&opt2!=3)
		{
			puts("输入非法！请再次输入！");
			continue;
		}
		break;
	}
	SqStack S;
	PosType start,end;
	start.x=1;start.y=0;	//起点坐标
	end.x=M-2;end.y=N-1;	//终点坐标
	memset(vis,0,sizeof(vis));
	if(opt==1) Random();
	else
	{
		freopen("input.txt","r",stdin);
		for(int i=0;i<=M-1;i++)
			for(int j=0;j<=N-1;j++)
				scanf("%d",&Maze[i][j]);
	}
	if(opt2==1)
	{
		while(!DynamicMazePath(Maze[M][N],start,end,S)) puts("随机生成的迷宫无解！"),Random();
		puts("找到路径！");
	}
	else if(opt2==2)
	{
		InitStack(S);
		count=0;
		while(count==0)//防止没有路径的情况
		{
			SElemType now;
			now.seat=start;
			Push(S,now);
			dfs(start,end,S);
			if(opt==2&&count==0)
			{
				puts("您输入文件内的迷宫无解！");
				break;
			}
		}
	}
	else
	{
		InitStack(S);
		count=0;
		while(1)//防止没有路径的情况
		{
			SElemType now;
			now.seat=start;
			Push(S,now);
			dfs2(start,end,S,1);
			if(count==0)
			{
				if(opt==2)
				{
					puts("您输入文件内的迷宫无解！");
					break;
				}
				continue;
			}
			printf("一共有%d条最短路\n最短的长度为%d\n",count,minlength);
			break;
		}
	}
	return 0;
}
